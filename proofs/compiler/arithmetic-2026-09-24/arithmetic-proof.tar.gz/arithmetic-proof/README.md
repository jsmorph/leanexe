# General arithmetic compiler proof

This source package proves `Project.Compiler.ArithmeticCompilerAudit` and its imported theorems for every
successfully admitted arithmetic declaration, using the production compiler
and byte emitter definitions. It contains no generated per-program theorem.

Install Python 3, Git and `leanprover/lean4:v4.34.0-rc2`. On macOS, a C compiler is also needed
by the runner. Set LEANRUN_TOOLCHAIN to the pinned installation if needed.
Where local execution is authorized, set LEANRUN_LOCAL=1; the runner retains
its shared lock, one Lean thread, and timeout. Otherwise it uses systemd limits.
On this project's authorized Mac, LEANRUN_INHERIT_PRIORITY=1 is also used.

From this directory, run:

```sh
python3 tools/arithmetic-package.py verify .
```

The verifier checks all bundled hashes and exact pins, requires no existing
package build, and invokes `tools/leanrun --timeout 900 lake build Project.Compiler.ArithmeticCompilerAudit`.
Lake may fetch the pinned third-party dependencies. To reuse existing pinned
third-party sources and caches, add `--dependencies /absolute/dependency/directory`.
Only the nine listed third-party packages are linked; original LeanExe, Project,
and Interpreter build products are never imported. No compiler CLI or generator
runs. All bundled Lean modules are rebuilt by the package's own Lake project.
Output and all nine theorem dependency audits are in verification.log and
verification-result.json. The runtime validator theorems allow only propext;
other audited compiler theorems allow propext, Classical.choice and Quot.sound.

The proof covers the restricted UInt64 arithmetic source grammar, exact output
bytes, decoding, validation, export lookup and terminating invocation in the
pinned interpreter. It does not prove CLI IO, all Lean evaluation, or agreement
of every external engine with that interpreter. The source supports UInt64
arguments/literals and nested add/sub/mul/unsigned division/remainder/bitwise
operations/masked shifts, subject to explicit format-size bounds. Lets,
branches, helpers, loops, custom instances and heap values are excluded.

The JSON inventory detects accidental content changes; it is not a signature.
Check this archive's SHA-256 against the separately published evidence to
establish its identity. Third-party dependencies remain part of the trust base.
